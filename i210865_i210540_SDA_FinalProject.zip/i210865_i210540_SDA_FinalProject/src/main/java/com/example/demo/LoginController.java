package com.example.demo;
//
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.scene.control.Label;
//import javafx.scene.control.PasswordField;
//import javafx.scene.control.TextField;
//import javafx.stage.Stage;
//
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.Objects;
//
//public class LoginController {
//
//    @FXML
//    private TextField usernameField;
//
//    @FXML
//    private PasswordField passwordField;
//
//    @FXML
//    private Label errorLabel;
//
//    @FXML
//    private void onLoginButtonClick(ActionEvent event) throws SQLException, IOException {
//        // Add your login logic here
//        String username = usernameField.getText();
//        String password = passwordField.getText();
//
//        // Example logic: Check if username and password are valid
//        try (Connection connection = DatabaseConnector.connect()) {
//            String query = "SELECT * FROM users WHERE username = ?";
//            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
//                preparedStatement.setString(1, username);
//
//                try (ResultSet resultSet = preparedStatement.executeQuery()) {
//                    if (resultSet.next()) {
//                        String storedPassword = resultSet.getString("password");
//                        if (password.equals(storedPassword)) {
//                            // Login successful, navigate to the homepage
//                            homepage(username);
//                        } else {
//                            errorLabel.setText("Incorrect password");
//                        }
//                    } else {
//                        errorLabel.setText("Username not found");
//                    }
//                }
//            }
//
//
//        }
//    }
//
//    private void homepage(String username) throws IOException {
//        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("profile.fxml"));
//        Parent homepage = fxmlLoader.load();
//        // Access the controller of the loaded profile.fxml file
//        profile profileController = fxmlLoader.getController();
//
//        // Pass the username to the profile controller
//        profileController.setUsername(username);
//
//        // Initialize the profile controller after setting the username
//        profileController.initialize();
//
//        Scene scene = new Scene(homepage, 800, 650);
//
//        // Access the Stage from the current event and set the new scene
//        Stage stage = (Stage) usernameField.getScene().getWindow();
//        stage.setScene(scene);
//    }
////    private void homepage() throws IOException {
////        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("profile.fxml"));
////        Parent homepage = fxmlLoader.load();
////        // Access the controller of the loaded profile.fxml file
////        profile profileController = fxmlLoader.getController();
////
////        String username = usernameField.getText();
////        // Pass the username to the profile controller
////        profileController.setUsername(username);
////        Scene scene = new Scene(homepage, 1000, 1000);
////
////        // Access the Stage from the current event and set the new scene
////        Stage stage = (Stage) usernameField.getScene().getWindow();
////        stage.setScene(scene);
////    }
//}



import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    private void onLoginButtonClick(ActionEvent event) throws SQLException, IOException {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (LoginService.validateUser(username, password)) {
            navigateToHomepage(username);
        } else {
            errorLabel.setText("Invalid username or password");
        }
    }

    private void navigateToHomepage(String username) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("profile.fxml"));
        Parent homepage = fxmlLoader.load();
        profile profileController = fxmlLoader.getController();
        profileController.setUsername(username);
        profileController.initialize();

        Scene scene = new Scene(homepage, 800, 650);
        Stage stage = (Stage) usernameField.getScene().getWindow();
        stage.setScene(scene);
    }
}

