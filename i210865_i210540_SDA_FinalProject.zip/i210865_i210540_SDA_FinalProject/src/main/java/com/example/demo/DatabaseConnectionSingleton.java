package com.example.demo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//SINGLETON PATTERN
public class DatabaseConnectionSingleton {
    private static DatabaseConnectionSingleton instance;
    private Connection connection;

    private DatabaseConnectionSingleton() {
        // Private constructor to prevent instantiation
        initializeConnection();
    }

    public static DatabaseConnectionSingleton getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnectionSingleton.class) {
                if (instance == null) {
                    instance = new DatabaseConnectionSingleton();
                }
            }
        }
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }

    private void initializeConnection() {
        String jdbcUrl = "jdbc:mysql://localhost:3306/he";
        String dbUsername = "root";
        String dbPassword = "l112233f";

        try {
            connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection errors
        }
    }
}
