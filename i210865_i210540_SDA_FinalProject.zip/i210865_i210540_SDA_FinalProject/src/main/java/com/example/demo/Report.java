package com.example.demo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class Report implements CaseStatusObserver{

    @Override
    public void updateCaseStatus(int caseId, String newStatus, String caseNotes, LocalDateTime timestamp) {
        // Implement logic to update the report with the new case status
        System.out.println("Report updated for Case ID: " + caseId + ", Status: " + newStatus);
    }

    @FXML
    private Button profileButton;

    @FXML
    private Button statusTrackingButton;

    @FXML
    private Button reportsButton;

    @FXML
    private Button researchButton;

    @FXML
    private Button creationButton;

    @FXML
    private Button documentManagementButton;

    @FXML
    private Button courtAppearanceButton;

    @FXML
    private ListView<String> reportTypeListView;

    private String username;

    // Create a method to set the username from another controller
    public void setUsername(String username) {
        this.username = username;
        System.out.println("Username in ReportController: " + username);
        // Additional logic to handle the username in the ReportController, if needed
    }

    @FXML
    private void handleProfileButtonClick() {
        // Handle profile button click
    }

    @FXML
    private void handleResearchButtonClick() {
        // Handle research button click
    }

    @FXML
    private void handleGenerateReport() {
        // Handle generate report button click
        // Implement the logic for generating the selected report type with custom options

        // Connect to MySQL and retrieve case information
        try (Connection connection = DatabaseConnector.connect()) {
            System.out.println("im in: " + username);
            String sql = "SELECT DISTINCT case_creation.case_id, title, description, case_notes, case_status\n" +
                    "FROM case_creation\n" +
                    "JOIN assigned_cases ON case_creation.case_id = assigned_cases.case_id\n" +
                    "WHERE lawyer_username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, username);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    StringBuilder reportContent = new StringBuilder();

                    while (resultSet.next()) {
                        int caseId = resultSet.getInt("case_id");
                        String caseTitle = resultSet.getString("title");
                        String caseDescription = resultSet.getString("description");
                        String caseNotes = resultSet.getString("case_notes");
                        String caseStatus = resultSet.getString("case_status");

                        // Append case information to the report content
                        reportContent.append("Case ID: ").append(caseId).append("\n");
                        reportContent.append("Case Title: ").append(caseTitle).append("\n");
                        reportContent.append("Case Description: ").append(caseDescription).append("\n");
                        reportContent.append("Case Notes: ").append(caseNotes).append("\n");
                        reportContent.append("Case Status: ").append(caseStatus).append("\n\n");
                    }

                    // Display the report in a popup
                    showReportPopup(reportContent.toString());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showReportPopup(String reportContent) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Case Report");
        alert.setHeaderText(null);
        alert.setContentText(reportContent);
        alert.showAndWait();
    }

    @FXML
    public void handleProfileButtonClick(ActionEvent event) throws IOException {
        // Close the current stage
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();

        // Open the profile window
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("profile.fxml"));
        Parent homepage = fxmlLoader.load();

        profile profileController = fxmlLoader.getController();
        profileController.setUsername(username);
        profileController.initialize();

        Scene scene = new Scene(homepage, 800, 500);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }


    public void handleresearchClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("research.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Research reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }

    public void handlestatustrackingClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseStatusController caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void handlecasecreationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("CaseCreation-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseCreation caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }
    public void handlenotificationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("notification-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        notification caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }
    public void handlecourtClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("court_view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        court caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

}
