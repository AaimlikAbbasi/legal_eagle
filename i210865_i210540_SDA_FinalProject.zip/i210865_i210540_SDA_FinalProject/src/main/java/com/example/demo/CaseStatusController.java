package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CaseStatusController implements Initializable {

    @FXML
    private Label caseStatusLabel;

    @FXML
    private ComboBox<String> statusComboBox;

    @FXML
    private ComboBox<CaseItem> caseComboBox;

    @FXML
    private TextArea caseNotesTextArea;

    @FXML
    private Label usernameLabel;

    //ENCAPSULATION
    private String username;

    public void setUsername(String username) {
        this.username = username;
        System.out.println("Username: " + username);
        // Retrieve lawyer data from MySQL and update UI
        loadDataFromMySQL();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // You can perform any initialization logic here
        // For example, updating UI components with data
        if (username != null) {
            usernameLabel.setText("Hello, " + username + "!");
        }
    }

    private void loadDataFromMySQL() {
        try (Connection connection = DatabaseConnector.connect()) {
            System.out.println("Username: " + username);
            String query = "SELECT case_id FROM assigned_cases WHERE lawyer_username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int caseId = resultSet.getInt("case_id");
                CaseItem caseItem = new CaseItem(caseId);
                caseComboBox.getItems().add(caseItem);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private List<CaseStatusObserver> observers = new ArrayList<>();

    public void addObserver(CaseStatusObserver observer) {
        observers.add(observer);
    }

    private void notifyObservers(int caseId, String newStatus, String caseNotes, LocalDateTime timestamp) {
        for (CaseStatusObserver observer : observers) {
            observer.updateCaseStatus(caseId, newStatus, caseNotes, timestamp);
        }
    }

    // Existing code...

    @FXML
    private void onSubmitButtonClick() {
        // Existing code...
        CaseItem selectedCase = caseComboBox.getValue();
        String selectedStatus = statusComboBox.getValue();
        String caseNotes = caseNotesTextArea.getText();

        if (selectedCase != null && selectedStatus != null && !caseNotes.isEmpty()) {
            updateCaseStatus(selectedCase.getCaseId(), selectedStatus, caseNotes);
            sendNotifications();
            recordStatusUpdate(selectedCase.getCaseId(), selectedStatus, caseNotes, LocalDateTime.now());
            caseStatusLabel.setText("Case Status: " + selectedStatus);
            clearFormFields();

            // Notify observers about the case status update
            notifyObservers(selectedCase.getCaseId(), selectedStatus, caseNotes, LocalDateTime.now());

            // Display success message in a new stage
            showSuccessAlert();

        } else {
            System.out.println("Please select a case, status, and enter case notes.");
        }
    }


//    @FXML
//    private void onSubmitButtonClick() {
//        CaseItem selectedCase = caseComboBox.getValue();
//        String selectedStatus = statusComboBox.getValue();
//        String caseNotes = caseNotesTextArea.getText();
//
//        if (selectedCase != null && selectedStatus != null && !caseNotes.isEmpty()) {
//            updateCaseStatus(selectedCase.getCaseId(), selectedStatus, caseNotes);
//            sendNotifications();
//            recordStatusUpdate(selectedCase.getCaseId(), selectedStatus, caseNotes, LocalDateTime.now());
//            caseStatusLabel.setText("Case Status: " + selectedStatus);
//            clearFormFields();
//
//            // Display success message in a new stage
//            showSuccessAlert();
//
//        } else {
//            System.out.println("Please select a case, status, and enter case notes.");
//        }
//    }

    private void showSuccessAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("Case status updated successfully!");

        // Show the alert and wait for the user to close it
        alert.showAndWait();
    }


    private void updateCaseStatus(int caseId, String newStatus, String caseNotes) {
        try (Connection connection = DatabaseConnector.connect()) {
            String query = "UPDATE case_creation SET case_status = ?, case_notes = ? WHERE case_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, newStatus);
            preparedStatement.setString(2, caseNotes);
            preparedStatement.setInt(3, caseId);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Case status updated successfully.");
            } else {
                System.out.println("Failed to update case status.");
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void sendNotifications() {
        // Implement logic to send notifications
    }

    private void recordStatusUpdate(int caseId, String status, String caseNotes, LocalDateTime timestamp) {
        // Implement logic to record the status update in the case history
    }

    private void clearFormFields() {
        caseComboBox.getSelectionModel().clearSelection();
        statusComboBox.getSelectionModel().clearSelection();
        caseNotesTextArea.clear();
    }

    @FXML
    public void handleProfileButtonClick(ActionEvent event) throws IOException {
        // Close the current stage
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();

        // Open the profile window
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("profile.fxml"));
        Parent homepage = fxmlLoader.load();

        profile profileController = fxmlLoader.getController();
        profileController.setUsername(username);
        profileController.initialize();

        Scene scene = new Scene(homepage, 800, 500);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }
    public void handlereportClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("report.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Report reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }
    public void handleresearchClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("research.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Research reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }
    public void handlestatustrackingClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseStatusController caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void handlecasecreationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("CaseCreation-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseCreation caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void handlenotificationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("notification-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        notification caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void handlecourtClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("court_view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        court caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

}
