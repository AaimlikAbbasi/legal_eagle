package com.example.demo;


public class Lawyer {
    private String name;
    private String joinDate;
    private String rating;
    private String phone;
    private String address;

    // Default constructor
    public Lawyer() {
    }

    // Parameterized constructor
    public Lawyer(String name, String joinDate, String rating, String phone, String address) {
        this.name = name;
        this.joinDate = joinDate;
        this.rating = rating;
        this.phone = phone;
        this.address = address;
    }

    // Getters and setters for each attribute

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(String joinDate) {
        this.joinDate = joinDate;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


}
