package com.example.demo;

public class CaseItem {
    private int caseId;

    public CaseItem(int caseId) {
        this.caseId = caseId;
    }

    public int getCaseId() {
        return caseId;
    }

    @Override
    public String toString() {
        return String.valueOf(caseId);
    }

}

