package com.example.demo;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;

import java.sql.*;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;


public class CaseCreation {



    @FXML
    private TextField titleTextField;

    @FXML
    private ComboBox<String> statusComboBox;

    @FXML
    private DatePicker dateDatePicker;

    @FXML
    private TextField classNoteTextField;

    @FXML
    private TextField descriptionTextField;


    @FXML
    private Button submitButton;

    @FXML
//    private String username;
//
//    public void setUsername(String username) {
//        this.username = username;
//        System.out.println("Username: " + username);
//        // Retrieve lawyer data from MySQL and update UI
//    }

    //ENCAPSULATION
    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
        System.out.println("Username: " + username);
    }

    @FXML
    public void initialize() {
        // Populate the statusComboBox with values
        statusComboBox.getItems().addAll("Open", "In Progress", "Closed");


    }


    @FXML
    protected void onSaveButtonClick() {
        System.out.println("button has been clicked");
        // Get the values from the input fields
        String title = titleTextField.getText();
        String classNote = classNoteTextField.getText();
        String description = descriptionTextField.getText();
        String status = statusComboBox.getValue();

        // Check if dateDatePicker value is not null before calling toString()
        String date = (dateDatePicker.getValue() != null) ? dateDatePicker.getValue().toString() : null;

        // Call a method to save the data to the database
        saveDataToDatabase(title, classNote, description, status, date,username);
    }

    @FXML
    public void court(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("court_view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        court caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void notification(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("notification-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        notification caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }
    private void saveDataToDatabase(String title, String classNote, String description, String status, String date, String lawyerUsername) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/he", "root", "l112233f");

            // Insert into case_creation table and retrieve the generated case_id
            String caseSql = "INSERT INTO case_creation (title, description, case_status, case_notes, date_created) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement caseStatement = conn.prepareStatement(caseSql, Statement.RETURN_GENERATED_KEYS)) {
                caseStatement.setString(1, title);
                caseStatement.setString(2, description);
                caseStatement.setString(3, status);
                caseStatement.setString(4, classNote);
                caseStatement.setString(5, date);

                // Execute the SQL statement and retrieve the generated keys
                int affectedRows = caseStatement.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("Creating case failed, no rows affected.");
                }

                try (ResultSet generatedKeys = caseStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int caseId = generatedKeys.getInt(1);

                        // Insert into assigned_cases table
                        String assignedSql = "INSERT INTO assigned_cases (lawyer_username, case_id) VALUES (?, ?)";
                        try (PreparedStatement assignedStatement = conn.prepareStatement(assignedSql)) {
                            assignedStatement.setString(1, lawyerUsername);
                            assignedStatement.setInt(2, caseId);

                            // Execute the SQL statement
                            assignedStatement.executeUpdate();

                            System.out.println("Data saved to the database.");
                        } catch (SQLException e) {
                            e.printStackTrace();
                            System.err.println("Error executing SQL statement for assigned_cases.");
                        }
                    } else {
                        throw new SQLException("Creating case failed, no case ID obtained.");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Error executing SQL statement for case_creation.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error establishing database connection.");
        }
    }

    public void profileclick(ActionEvent event) throws IOException {
        // Close the current stage
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();

        // Open the profile window
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("profile.fxml"));
        Parent homepage = fxmlLoader.load();

        profile profileController = fxmlLoader.getController();
        profileController.setUsername(username);
        profileController.initialize();

        Scene scene = new Scene(homepage, 800, 500);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void handlestatustrackingClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseStatusController caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    @FXML
    public void handlereportClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("report.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Report reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }

    public void handleresearchClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("research.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Research reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }


}
