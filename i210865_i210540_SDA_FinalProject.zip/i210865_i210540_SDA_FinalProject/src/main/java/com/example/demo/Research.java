package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Research {

    private String username;

    public void setUsername(String username) {
        this.username = username;
        System.out.println("Username: " + username);
    }

    @FXML
    private ComboBox<String> titleComboBox;

    @FXML
    private ComboBox<String> progressComboBox;

    @FXML
    private Button searchButton;

    @FXML
    private Label caseResearchLabel;

    @FXML
    private ListView<String> resultListView;

    @FXML
    private void onSearchButtonClick() {
        String selectedTitle = titleComboBox.getValue();
        String selectedProgress = progressComboBox.getValue();

        if (selectedTitle != null || selectedProgress != null) {
            // Connect to MySQL and execute the search
            searchInDatabase(selectedTitle, selectedProgress);
        } else {
            // Handle case where no options are selected
            // You might want to show an alert or update the UI accordingly
            System.out.println("Please select at least one option (title or progress).");
        }
    }


    //factory pattern implemented below
    private PreparedStatement createPreparedStatement(Connection connection, String selectedTitle, String selectedProgress)
            throws SQLException {
        StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM case_creation " +
                "JOIN assigned_cases ON case_creation.case_id = assigned_cases.case_id " +
                "WHERE ");

        if (selectedTitle != null) {
            sqlBuilder.append("title = ? ");
        }

        if (selectedTitle != null && selectedProgress != null) {
            sqlBuilder.append("AND ");
        }

        if (selectedProgress != null) {
            sqlBuilder.append("case_status = ? ");
        }

        if (username != null) {
            sqlBuilder.append("AND lawyer_username = ?");
        }

        String sql = sqlBuilder.toString();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        int parameterIndex = 1;

        if (selectedTitle != null) {
            preparedStatement.setString(parameterIndex++, selectedTitle);
        }

        if (selectedProgress != null) {
            preparedStatement.setString(parameterIndex++, selectedProgress);
        }

        if (username != null) {
            preparedStatement.setString(parameterIndex, username);
        }

        return preparedStatement;
    }

    private void searchInDatabase(String selectedTitle, String selectedProgress) {
        try (Connection connection = DatabaseConnector.connect()) {
            // Use the factory method to create PreparedStatement
            try (PreparedStatement preparedStatement = createPreparedStatement(connection, selectedTitle, selectedProgress);
                 ResultSet resultSet = preparedStatement.executeQuery()) {
                processSearchResults(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection or query execution errors
        }
    }


    private void processSearchResults(ResultSet resultSet) {
        // Check if the result set has any rows
        try {
            if (!resultSet.next()) {
                System.out.println("No results found.");
                showNoResultsAlert();
            } else {
                // Create a StringBuilder to hold the result text
                StringBuilder resultText = new StringBuilder();

                do {
                    // Assuming you have appropriate columns in your table
                    String caseId = resultSet.getString("case_id");
                    String caseTitle = resultSet.getString("title");
                    String caseDescription = resultSet.getString("description");
                    String caseStatus = resultSet.getString("case_status");

                    // Format the result and add to the StringBuilder
                    resultText.append("Case ID: ").append(caseId).append("\n");
                    resultText.append("Title: ").append(caseTitle).append("\n");
                    resultText.append("Description: ").append(caseDescription).append("\n");
                    resultText.append("Status: ").append(caseStatus).append("\n\n");
                } while (resultSet.next());

                // Display the results in a pop-up window
                showResultsPopup(resultText.toString());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showResultsPopup(String results) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Search Results");
        alert.setHeaderText(null);
        alert.setContentText(results);
        alert.showAndWait();
    }

    private void showNoResultsAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Search Results");
        alert.setHeaderText(null);
        alert.setContentText("No results found.");
        alert.showAndWait();
    }

    @FXML
    public void handlereportClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("report.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Report reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }

    public void handleProfileButtonClick(ActionEvent event) throws IOException {
        // Close the current stage
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();

        // Open the profile window
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("profile.fxml"));
        Parent homepage = fxmlLoader.load();

        profile profileController = fxmlLoader.getController();
        profileController.setUsername(username);
        profileController.initialize();

        Scene scene = new Scene(homepage, 800, 500);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    public void handlestatustrackingClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseStatusController caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void handlecasecreationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("CaseCreation-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseCreation caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void handlenotificationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("notification-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        notification caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }
    public void handlecourtClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("court_view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        court caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }


}
