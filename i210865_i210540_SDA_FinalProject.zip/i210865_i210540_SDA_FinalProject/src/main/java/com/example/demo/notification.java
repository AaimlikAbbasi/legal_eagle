package com.example.demo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class notification{


    private String username;

    public void setUsername(String username) {
        this.username = username;
        System.out.println("Username: " + username);

    }
    @FXML
    private TextField usernameTextField;

    @FXML
    private TextArea notificationTextArea;

    @FXML
    private Button displayButton;


    @FXML
    public void handleDisplayButton(ActionEvent event) {
        // Use the username set through setUsername method
        String notifications = fetchNotifications(username);
        notificationTextArea.setText(notifications);
    }



//    public void court(ActionEvent event) {
//        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//        currentStage.close();
//
//        // Open the profile window
//        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("court_view.fxml"));
//        Parent homepage = fxmlLoader.load();
//
//        court profileController = fxmlLoader.getController();
//        profileController.setUsername(username);
//        profileController.initialize();
//
//        Scene scene = new Scene(homepage, 800, 500);
//        Stage stage = new Stage();
//        stage.setScene(scene);
//        stage.show();
//
//    }

    @FXML
    public void handlecourtClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("court_view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        court caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }
    @FXML
    public void handlecasecreationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("CaseCreation-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseCreation caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }



    private String fetchNotifications(String username) {
        StringBuilder notifications = new StringBuilder();

        // Use the Singleton pattern to get the database connection instance
        Connection connection = DatabaseConnectionSingleton.getInstance().getConnection();

        try {
            String sql = "SELECT timestamp, notification_alert FROM notification WHERE username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, username);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        notifications.append(resultSet.getTimestamp("timestamp"))
                                .append(" - ")
                                .append(resultSet.getString("notification_alert"))
                                .append("\n");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showErrorAlert("Error", "Failed to fetch notifications from the database.");
        }

        return notifications.toString();
    }


    private void showErrorAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public void profileclick(ActionEvent event) throws IOException {
        // Close the current stage
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();

        // Open the profile window
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("profile.fxml"));
        Parent homepage = fxmlLoader.load();

        profile profileController = fxmlLoader.getController();
        profileController.setUsername(username);
        profileController.initialize();

        Scene scene = new Scene(homepage, 800, 500);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void handlestatustrackingClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseStatusController caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    @FXML
    public void handlereportClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("report.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Report reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }

    public void handleresearchClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("research.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Research reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }
}
