package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class profile {

    private String username;

    @FXML
    private Label nameLabel;

    @FXML
    private Label joinDateLabel;

    @FXML
    private Label ratingLabel;

    @FXML
    private Label phoneNumberLabel; // Added declaration

    @FXML
    private Label addressLabel; // Added declaration

    @FXML
    private ListView<String> casesListView;

    public void setUsername(String username) {
        this.username = username;
        System.out.println("Username: " + username);
        // Retrieve lawyer data from MySQL and update UI
        loadDataFromMySQL();
    }

    @FXML
    public void initialize() {
        // Initialization code if needed
    }

//    private void loadDataFromMySQL() {
//        try (Connection connection = DatabaseConnector.connect()) {
//            String sql = "SELECT * FROM he.lawyers WHERE user_username = ?";
//            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
//                System.out.println("SQL Query: " + preparedStatement.toString());
//                preparedStatement.setString(1, username);
//                try (ResultSet resultSet = preparedStatement.executeQuery()) {
//                    if (resultSet.next()) {
//                        nameLabel.setText(resultSet.getString("name"));
//                        joinDateLabel.setText(resultSet.getString("join_date"));
//                        ratingLabel.setText(resultSet.getString("rating"));
//                        phoneNumberLabel.setText(resultSet.getString("phone"));
//                        addressLabel.setText(resultSet.getString("address"));
//
//                         //Retrieve and display cases
//                    }
//                }
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }

    private Lawyer lawyer;

    // Existing code

    private void loadDataFromMySQL() {
        try (Connection connection = DatabaseConnector.connect()) {
            String sql = "SELECT * FROM he.lawyers WHERE user_username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                System.out.println("SQL Query: " + preparedStatement.toString());
                preparedStatement.setString(1, username);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // Use parameterized constructor to create Lawyer instance
                        lawyer = new Lawyer(
                                resultSet.getString("name"),
                                resultSet.getString("join_date"),
                                resultSet.getString("rating"),
                                resultSet.getString("phone"),
                                resultSet.getString("address")
                        );

                        // Update UI
                        updateUI();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void updateUI() {
        // Check if the lawyer instance is not null
        if (lawyer != null) {
            // Set the text of labels with lawyer information
            nameLabel.setText(lawyer.getName());
            joinDateLabel.setText(lawyer.getJoinDate());
            ratingLabel.setText(lawyer.getRating());
            phoneNumberLabel.setText(lawyer.getPhone());
            addressLabel.setText(lawyer.getAddress());

            // Optionally, you can update other UI components based on the lawyer information
            // casesListView.setItems(...);
        }
    }





    @FXML
    public void handlereportClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("report.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Report reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }
    public void handleresearchClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("research.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Research reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }

    @FXML
    public void handlestatustrackingClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseStatusController caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void handlecasecreationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("CaseCreation-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseCreation caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void handlenotificationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("notification-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        notification caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void handlecourtClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("court_view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        court caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }

    public void logout(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
        Parent root = loader.load();

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }


}
