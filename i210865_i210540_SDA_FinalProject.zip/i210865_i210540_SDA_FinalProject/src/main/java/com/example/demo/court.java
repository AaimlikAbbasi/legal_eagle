package com.example.demo;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class court {

    private String username;

    public void setUsername(String username) {
        this.username = username;
        System.out.println("Username in CaseStatusControl: " + username);
        // You can use the username as needed in this controller
    }
    @FXML
    private TextField caseIdTextField;
    @FXML
    private TextField scheduledTimeTextField;
    @FXML
    private TextField locationTextField;
    @FXML
    private TextField titledescription;  // Add the TextField for description
    @FXML
    private DatePicker dateDatePicker;
    @FXML
    private TextField displayCaseIdTextField;
    @FXML
    private TextArea displayTextArea;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/he";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "l112233f";

    @FXML
    public void handleSubmitButton(ActionEvent event) {
        // Validation: Check if required fields are not empty
        if (caseIdTextField.getText().isEmpty() || scheduledTimeTextField.getText().isEmpty()
                || locationTextField.getText().isEmpty() || titledescription.getText().isEmpty() || dateDatePicker.getValue() == null) {
            showAlert("Error", "Please fill in all the fields.");
            return;
        }

        // Get data from UI components
        int caseId = Integer.parseInt(caseIdTextField.getText());
        String scheduledDate = dateDatePicker.getValue().toString();
        String scheduledTime = scheduledTimeTextField.getText();
        String location = locationTextField.getText();
        String description = titledescription.getText();  // Get the description value

        // Call database operation to insert data
        insertCourtAppearance(caseId, scheduledDate, scheduledTime, location, description);

        // Show success message to the user
        showAlert("Success", "Court Appearance data inserted successfully.");
    }
    @FXML
    public void notification(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("notification-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        notification caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }
    @FXML
    public void handlecasecreationClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("CaseCreation-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseCreation caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }
    @FXML
    public void handleDisplayButton(ActionEvent event) {
        // Validation: Check if case ID is not empty
        if (displayCaseIdTextField.getText().isEmpty()) {
            showAlert("Error", "Please enter a Case ID.");
            return;
        }

        // Get case ID from UI component
        int caseId = Integer.parseInt(displayCaseIdTextField.getText());

        // Call database operation to fetch and display data
        List<String> courtAppearances = fetchCourtAppearances(caseId);

        // Create a new Stage to display court appearances
        Stage stage = new Stage();
        stage.setTitle("Court Appearances");

        // Use a GridPane to organize appearance details
        GridPane gridPane = new GridPane();
        gridPane.setVgap(10); // Vertical gap between elements

        // Add a Label for each appearance detail
        int row = 0;
        for (String appearance : courtAppearances) {
            Label label = new Label(appearance);
            gridPane.add(label, 0, row);
            row++;
        }

        // Create a Scene and set it on the Stage
        Scene scene = new Scene(gridPane, 400, 300); // Set width and height as needed
        stage.setScene(scene);

        // Show the Stage
        stage.show();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void insertCourtAppearance(int caseId, String scheduledDate, String scheduledTime, String location, String description) {
        String sql = "INSERT INTO courtappearance (case_id, scheduled_date, scheduled_time, location, details) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, caseId);
            preparedStatement.setString(2, scheduledDate);
            preparedStatement.setString(3, scheduledTime);
            preparedStatement.setString(4, location);
            preparedStatement.setString(5, description);

            preparedStatement.executeUpdate();

            System.out.println("Court Appearance data inserted successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error inserting data into courtappearance table.");
        }
    }

    public static List<String> fetchCourtAppearances(int caseId) {
        List<String> courtAppearances = new ArrayList<>();
        String sql = "SELECT * FROM courtappearance WHERE case_id = ?";

        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, caseId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    String appearanceDetails = "ID: " + resultSet.getInt("appearance_id") +
                            ", Date: " + resultSet.getString("scheduled_date") +
                            ", Time: " + resultSet.getString("scheduled_time") +
                            ", Location: " + resultSet.getString("location");

                    courtAppearances.add(appearanceDetails);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error fetching court appearances.");
        }

        return courtAppearances;
    }
    public void profileclick(ActionEvent event) throws IOException {
        // Close the current stage
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();

        // Open the profile window
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("profile.fxml"));
        Parent homepage = fxmlLoader.load();

        profile profileController = fxmlLoader.getController();
        profileController.setUsername(username);
        profileController.initialize();

        Scene scene = new Scene(homepage, 800, 500);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void handlestatustrackingClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        CaseStatusController caseStatusControl = loader.getController();

        // Pass the username to the next page
        caseStatusControl.setUsername(username);

        // Get the current stage
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Set the new scene to the current stage
        stage.setScene(new Scene(root));

        stage.show();
    }
    @FXML
    public void handlereportClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("report.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Report reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }

    public void handleresearchClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("research.fxml"));
        Parent root = loader.load();

        // Access the controller of the next page
        Research reportController = loader.getController();

        // Pass the username to the next page
        reportController.setUsername(username);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Create a new scene with the specified width and height
        Scene scene = new Scene(root, 800, 500);

        // Set the new scene to the current stage
        stage.setScene(scene);

        stage.show();
    }
}