package com.example.demo;

import java.time.LocalDateTime;

public interface CaseStatusObserver {
    void updateCaseStatus(int caseId, String newStatus, String caseNotes, LocalDateTime timestamp);
}
